#ifndef DEFINES_H
#define DEFINES_H

#include <sys/types.h>

// La chiave della coda di messaggi e' ottenuta con ftok
#define KEY_PATH "/tmp"
#define KEY_PROJ 'S'

// Tipi di messaggio inviati al server. Il server riceve con msgtyp = -MSG_SERVER_MAX,
// quindi i tipi piu' bassi hanno la precedenza
#define MSG_DONE 1    // worker -> server: elaborazione terminata
#define MSG_ADMIN 2   // admin -> server: comando
#define MSG_REQUEST 3 // client -> server: richiesta di impronta
#define MSG_SERVER_MAX 3

// Le risposte al processo con pid P hanno mtype = MSG_REPLY_BASE + P
#define MSG_REPLY_BASE 1000L

#define HASH_HEX_LEN 65
#define TEXT_LEN 80 // deve contenere almeno un'impronta esadecimale
_Static_assert(TEXT_LEN >= HASH_HEX_LEN, "TEXT_LEN troppo piccolo per l'impronta");

// Comandi del client amministratore
#define CMD_SET_LIMIT 1
#define CMD_STATUS 2

struct message {
    long mtype;
    pid_t pid;        // mittente (client/admin) o worker (MSG_DONE)
    int shmid;        // richiesta: segmento di memoria condivisa
    int semid;        // richiesta: insieme di semafori
    int cmd;          // comando admin
    int status;       // risposta: 0 = ok, 1 = errore
    int more;         // risposta: 1 = seguono altri messaggi
    long value;       // comando admin: parametro
    long size;        // richiesta: dimensione del file in byte
    char text[TEXT_LEN]; // nome del file, oppure testo della risposta
};

// La dimensione del messaggio e' quella di tutto tranne mtype
#define MSG_SIZE (sizeof(struct message) - sizeof(long))

// Buffer in memoria condivisa: il client scrive il file a blocchi,
// il worker li legge
#define SHM_CHUNK 4096
#define CHUNK_ABORT 0xFFFFFFFFu // len speciale: errore di lettura nel client

struct shm_buf {
    unsigned int len;              // byte validi in data (0 = fine del file)
    unsigned char data[SHM_CHUNK];
};

// Semafori (insieme da 2), schema produttore/consumatore
#define SEM_EMPTY 0 // 1 = buffer libero: il client puo' scrivere
#define SEM_FULL 1  // 1 = buffer pieno: il worker puo' leggere

// Semaforo (insieme da 1) di presenza del server: stessa chiave della coda.
// Il server lo tiene a 1 mentre e' in esecuzione (vedi server.c e client.c)
#define SEM_ALIVE 0

#endif
