#ifndef ERR_EXIT_H
#define ERR_EXIT_H

// Stampa un messaggio di errore (con la descrizione di errno) e termina
void errExit(const char *msg);

#endif
