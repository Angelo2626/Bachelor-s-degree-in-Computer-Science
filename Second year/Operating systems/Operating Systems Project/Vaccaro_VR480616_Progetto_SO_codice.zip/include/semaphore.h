#ifndef SEMAPHORE_H
#define SEMAPHORE_H

// Esegue un'operazione sul semaforo sem_num dell'insieme semid:
// sem_op = -1 acquisisce (wait), sem_op = +1 rilascia (signal)
void semOp(int semid, unsigned short sem_num, short sem_op);

#endif
