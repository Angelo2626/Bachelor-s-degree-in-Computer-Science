#ifndef SEMUN_H
#define SEMUN_H

#include <sys/sem.h>

// Definizione dell'unione semun (va definita esplicitamente).
// Su macOS e' gia' definita da <sys/sem.h>.
#ifndef __APPLE__
union semun {
    int val;
    struct semid_ds *buf;
    unsigned short *array;
};
#endif

#endif
