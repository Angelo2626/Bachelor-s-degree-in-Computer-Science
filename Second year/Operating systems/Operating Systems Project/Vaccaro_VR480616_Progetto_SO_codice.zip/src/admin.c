#include "defines.h"
#include "err_exit.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/stat.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
    struct message m = {0};
    m.mtype = MSG_ADMIN;
    m.pid = getpid();

    if (argc == 3 && strcmp(argv[1], "limit") == 0) {
        m.cmd = CMD_SET_LIMIT;
        m.value = atol(argv[2]);
    } else if (argc == 2 && strcmp(argv[1], "status") == 0) {
        m.cmd = CMD_STATUS;
    } else {
        printf("Usage: %s limit <N>   set the maximum number of processes\n", argv[0]);
        printf("       %s status      show running and pending requests\n", argv[0]);
        exit(1);
    }

    key_t key = ftok(KEY_PATH, KEY_PROJ);
    if (key == -1)
        errExit("ftok failed");
    int msqid = msgget(key, S_IRUSR | S_IWUSR);
    if (msqid == -1) {
        printf("Server not reachable (is it running?)\n");
        exit(1);
    }

    if (msgsnd(msqid, &m, MSG_SIZE, 0) == -1)
        errExit("msgsnd failed");

    // Se il server non risponde entro 5 secondi SIGALRM termina il processo
    alarm(5);

    // La risposta puo' essere composta da piu' messaggi (campo more)
    int status;
    do {
        if (msgrcv(msqid, &m, MSG_SIZE, MSG_REPLY_BASE + getpid(), 0) == -1)
            errExit("msgrcv failed");
        if (m.text[0] != '\0')
            printf("%s\n", m.text);
        status = m.status;
    } while (m.more);

    return status;
}
