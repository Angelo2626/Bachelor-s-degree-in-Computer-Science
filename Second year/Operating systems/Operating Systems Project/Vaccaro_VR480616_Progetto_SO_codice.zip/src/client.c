#include "defines.h"
#include "err_exit.h"
#include "semun.h"

#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/sem.h>
#include <sys/shm.h>
#include <sys/stat.h>
#include <unistd.h>

#define SERVER_CHECK 2 // secondi fra un controllo e l'altro della presenza del server

int shmid = -1;
int semid = -1;
int msqid = -1;
int aliveSemid = -1; // semaforo di presenza del server (stessa chiave della coda)
key_t serverKey;
volatile sig_atomic_t alarmed = 0;

// Rimuove la memoria condivisa e i semafori creati da questo client
void cleanup(void) {
    if (shmid != -1)
        shmctl(shmid, IPC_RMID, NULL);
    if (semid != -1)
        semctl(semid, 0 /* ignored */, IPC_RMID, 0 /* ignored */);
    shmid = semid = -1;
}

// Vero se il server e' ancora vivo: il suo semaforo di presenza, impostato con
// SEM_UNDO, viene azzerato dal kernel se il server termina in qualunque modo,
// anche con kill -9, ma l'oggetto resta finche' non viene rimosso esplicitamente
int serverAlive(void) {
    if (aliveSemid == -1) {
        aliveSemid = semget(serverKey, 1, S_IRUSR | S_IWUSR);
        if (aliveSemid == -1)
            return 1; // il server potrebbe essere appena partito: non e' un errore
    }
    return semctl(aliveSemid, SEM_ALIVE, GETVAL) == 1;
}

// P/V sul semaforo, con un controllo periodico (ogni SERVER_CHECK secondi, via
// alarm) che il server sia ancora vivo. Se il server ha invece rimosso i
// semafori, semop fallisce con EIDRM o, in una corsa piu' stretta, EINVAL: in
// entrambi i casi si legge il motivo che il server aveva gia' inviato
void semOpClient(unsigned short sem_num, short sem_op) {
    struct sembuf sop = {.sem_num = sem_num, .sem_op = sem_op, .sem_flg = 0};

    for (;;) {
        alarmed = 0;
        alarm(SERVER_CHECK);
        int r = semop(semid, &sop, 1);
        alarm(0);
        if (r == 0)
            return;

        if (errno == EINTR) {
            if (alarmed && !serverAlive()) {
                printf("Server not reachable: stale message queue (server crashed?)\n");
                exit(1);
            }
            continue; // il server e' vivo ma occupato, oppure interrotto da altro
        }
        if (errno != EIDRM && errno != EINVAL)
            errExit("semop failed");

        struct message m;
        if (msgrcv(msqid, &m, MSG_SIZE, MSG_REPLY_BASE + getpid(), IPC_NOWAIT) != -1)
            printf("Server error: %s\n", m.text);
        else
            printf("Request aborted by the server\n");
        exit(1);
    }
}

void sigHandler(int sig) {
    (void)sig;
    cleanup();
    _exit(EXIT_FAILURE);
}

void alarmHandler(int sig) {
    (void)sig;
    alarmed = 1;
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <file>\n", argv[0]);
        exit(1);
    }
    char *path = argv[1];

    struct stat st;
    if (stat(path, &st) == -1 || !S_ISREG(st.st_mode)) {
        printf("File %s does not exist or is not a regular file\n", path);
        exit(1);
    }
    int file = open(path, O_RDONLY, 0);
    if (file == -1)
        errExit("open failed");

    // Coda di messaggi del server (deve esistere gia')
    serverKey = ftok(KEY_PATH, KEY_PROJ);
    if (serverKey == -1)
        errExit("ftok failed");
    msqid = msgget(serverKey, S_IRUSR | S_IWUSR);
    if (msqid == -1) {
        printf("Server not reachable (is it running?)\n");
        exit(1);
    }

    // Pulizia delle risorse anche con Ctrl-C
    atexit(cleanup);
    if (signal(SIGINT, sigHandler) == SIG_ERR || signal(SIGTERM, sigHandler) == SIG_ERR ||
        signal(SIGALRM, alarmHandler) == SIG_ERR)
        errExit("change signal handler failed");

    // Memoria condivisa e semafori (uno per "buffer libero", uno per "buffer pieno")
    shmid = shmget(IPC_PRIVATE, sizeof(struct shm_buf), S_IRUSR | S_IWUSR);
    if (shmid == -1)
        errExit("shmget failed");
    struct shm_buf *buf = (struct shm_buf *)shmat(shmid, NULL, 0);
    if (buf == (void *)-1)
        errExit("shmat failed");

    semid = semget(IPC_PRIVATE, 2, S_IRUSR | S_IWUSR);
    if (semid == -1)
        errExit("semget failed");
    unsigned short values[] = {1, 0}; // EMPTY = 1, FULL = 0
    union semun arg;
    arg.array = values;
    if (semctl(semid, 0 /* ignored */, SETALL, arg) == -1)
        errExit("semctl SETALL failed");

    // Richiesta al server: contiene la dimensione, usata per la schedulazione
    struct message m = {0};
    m.mtype = MSG_REQUEST;
    m.pid = getpid();
    m.shmid = shmid;
    m.semid = semid;
    m.size = st.st_size;
    char *name = strrchr(path, '/');
    name = name ? name + 1 : path;
    snprintf(m.text, TEXT_LEN, "%s", name);
    if (msgsnd(msqid, &m, MSG_SIZE, 0) == -1)
        errExit("msgsnd failed");

    // Trasferimento del file a blocchi tramite la memoria condivisa.
    // Il primo blocco viene scritto subito, poi si attende che il worker
    // (avviato dal server quando arriva il turno) abbia letto il precedente.
    ssize_t bR;
    do {
        semOpClient(SEM_EMPTY, -1);
        bR = read(file, buf->data, SHM_CHUNK);
        if (bR < 0) {
            printf("Read failed\n");
            buf->len = CHUNK_ABORT;
            semOpClient(SEM_FULL, 1);
            exit(1);
        }
        buf->len = (unsigned int)bR;
        semOpClient(SEM_FULL, 1);
    } while (bR > 0);
    close(file);

    // Attesa della risposta, indirizzata al nostro pid
    if (msgrcv(msqid, &m, MSG_SIZE, MSG_REPLY_BASE + getpid(), 0) == -1)
        errExit("msgrcv failed");
    if (m.status != 0) {
        printf("Server error: %s\n", m.text);
        exit(1);
    }
    printf("%s  %s\n", m.text, path);

    return 0;
}
