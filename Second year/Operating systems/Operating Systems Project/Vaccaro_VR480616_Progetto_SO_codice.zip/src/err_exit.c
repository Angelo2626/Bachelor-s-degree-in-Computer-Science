#include "err_exit.h"

#include <stdio.h>
#include <stdlib.h>

void errExit(const char *msg) {
    perror(msg);
    exit(EXIT_FAILURE);
}
