#include "defines.h"
#include "err_exit.h"
#include "semaphore.h"
#include "semun.h"

#include <errno.h>
#include <getopt.h>
#include <openssl/sha.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/sem.h>
#include <sys/shm.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

#define MAX_PROCS 64
#define DEFAULT_PROCS 2
#define MAX_PENDING 100
#define WORKER_TIMEOUT 10 // secondi di attesa massima di un blocco dal client
#define MAX_STATUS_LINES 8 // righe massime per sezione di admin status
#define AGING_RATE 10000 // byte "recuperati" per ogni secondo di attesa in coda (politica sjf)

#define FCFS 0
#define SJF 1

// Richiesta in attesa di essere servita
struct pending {
    struct message req;
    time_t arrival; // usato dalla politica sjf per l'aging
};

// Worker in esecuzione
struct active {
    int used;
    pid_t pid;
    struct message req;
};

int msqid = -1;
int maxProcs = DEFAULT_PROCS;
int policy = SJF;
useconds_t delayUs = 0; // rallentamento artificiale per blocco, utile per i test
volatile sig_atomic_t stop = 0;

// Richieste pendenti, in ordine di arrivo (indice 0 = la piu' vecchia)
struct pending pend[MAX_PENDING];
int pendCount = 0;

struct active act[MAX_PROCS];
int running = 0;

void sigHandler(int sig) {
    if (sig == SIGALRM)
        alarm(1); // sveglia periodica: interrompe msgrcv per controllare i worker
    else
        stop = 1;
}

// Invia un messaggio di risposta al processo to (senza mai bloccare il server)
void sendReply(pid_t to, int status, int more, const char *text) {
    struct message r = {0};
    r.mtype = MSG_REPLY_BASE + to;
    r.status = status;
    r.more = more;
    snprintf(r.text, TEXT_LEN, "%s", text);
    msgsnd(msqid, &r, MSG_SIZE, IPC_NOWAIT);
}

// ------------------------------ worker ------------------------------

// Codice eseguito dal processo figlio: legge il file dalla memoria condivisa
// e calcola l'impronta
void worker(struct message *req) {
    // Con SIGALRM di default il worker termina se il client non manda piu' dati
    if (signal(SIGINT, SIG_DFL) == SIG_ERR || signal(SIGTERM, SIG_DFL) == SIG_ERR ||
        signal(SIGALRM, SIG_DFL) == SIG_ERR)
        errExit("reset signal handler failed");

    struct shm_buf *buf = (struct shm_buf *)shmat(req->shmid, NULL, 0);
    if (buf == (void *)-1)
        errExit("worker shmat failed");

    SHA256_CTX ctx;
    SHA256_Init(&ctx);

    int status = 0;
    char text[TEXT_LEN];
    while (1) {
        alarm(WORKER_TIMEOUT); // se il client e' morto, il worker non resta bloccato
        semOp(req->semid, SEM_FULL, -1);
        alarm(0);
        unsigned int len = buf->len;
        if (len == 0)
            break; // fine del file
        if (len == CHUNK_ABORT || len > SHM_CHUNK) {
            status = 1;
            snprintf(text, TEXT_LEN, "transfer aborted by the client");
            break;
        }
        // Blocchi da 32 byte come negli esempi: il calcolo e' volutamente lento
        for (unsigned int off = 0; off < len; off += 32) {
            unsigned int n = (len - off < 32) ? len - off : 32;
            SHA256_Update(&ctx, buf->data + off, n);
        }
        if (delayUs)
            usleep(delayUs);
        semOp(req->semid, SEM_EMPTY, 1);
    }

    if (status == 0) {
        unsigned char hash[32];
        SHA256_Final(hash, &ctx);
        for (int i = 0; i < 32; i++)
            sprintf(text + i * 2, "%02x", hash[i]);
    }
    if (shmdt(buf) == -1)
        errExit("worker shmdt failed");

    // Risposta al client e notifica di fine al server
    struct message m = {0};
    m.mtype = MSG_REPLY_BASE + req->pid;
    m.status = status;
    snprintf(m.text, TEXT_LEN, "%s", text);
    if (msgsnd(msqid, &m, MSG_SIZE, 0) == -1)
        errExit("worker msgsnd failed");

    m.mtype = MSG_DONE;
    m.pid = getpid();
    if (msgsnd(msqid, &m, MSG_SIZE, 0) == -1)
        errExit("worker msgsnd done failed");

    exit(0);
}

// --------------------------- schedulazione ---------------------------

void enqueue(struct message *req) {
    if (pendCount == MAX_PENDING) {
        sendReply(req->pid, 1, 0, "server busy: too many pending requests");
        semctl(req->semid, 0, IPC_RMID, 0);
        shmctl(req->shmid, IPC_RMID, NULL); // il client potrebbe essere morto nel frattempo
        return;
    }
    pend[pendCount].req = *req;
    pend[pendCount].arrival = time(NULL);
    pendCount++;
    printf("[server] request from client %d: %s (%ld B), pending: %d\n", req->pid, req->text,
           req->size, pendCount);
}

// Dimensione "invecchiata": diminuisce con l'attesa in coda, cosi' una richiesta
// ferma da tempo finisce comunque per essere scelta anche se il file e' grande
// (evita la starvation quando arrivano in continuazione file piu' piccoli)
long agedSize(long size, time_t waited) {
    long credit = (long)waited * AGING_RATE;
    return size > credit ? size - credit : 0;
}

// Estrae la prossima richiesta: FCFS = la piu' vecchia,
// SJF = il file piu' piccolo una volta applicato l'aging (a parita', la piu' vecchia)
struct message dequeue(void) {
    int best = 0;
    if (policy == SJF) {
        time_t now = time(NULL);
        long bestScore = agedSize(pend[0].req.size, now - pend[0].arrival);
        for (int i = 1; i < pendCount; i++) {
            long score = agedSize(pend[i].req.size, now - pend[i].arrival);
            if (score < bestScore) {
                bestScore = score;
                best = i;
            }
        }
    }
    struct message req = pend[best].req;
    for (int i = best; i < pendCount - 1; i++)
        pend[i] = pend[i + 1];
    pendCount--;
    return req;
}

// Avvia dei worker finche' ci sono richieste e c'e' posto
void dispatch(void) {
    while (running < maxProcs && pendCount > 0) {
        struct message req = dequeue();

        pid_t pid = fork();
        switch (pid) {
        case -1:
            sendReply(req.pid, 1, 0, "fork failed");
            semctl(req.semid, 0, IPC_RMID, 0);
            shmctl(req.shmid, IPC_RMID, NULL); // il client potrebbe essere morto nel frattempo
            break;
        case 0: /* Processo figlio */
            worker(&req);
            break;
        default: /* Processo padre */
            for (int i = 0; i < MAX_PROCS; i++) {
                if (!act[i].used) {
                    act[i].used = 1;
                    act[i].pid = pid;
                    act[i].req = req;
                    break;
                }
            }
            running++;
            printf("[server] started worker %d for client %d: %s (%ld B) [%d/%d]\n", pid,
                   req.pid, req.text, req.size, running, maxProcs);
        }
    }
}

// Libera lo slot del worker pid; ritorna la voce oppure NULL se non c'e'
struct active *release(pid_t pid) {
    for (int i = 0; i < MAX_PROCS; i++) {
        if (act[i].used && act[i].pid == pid) {
            act[i].used = 0;
            running--;
            return &act[i];
        }
    }
    return NULL;
}

// Consuma i MSG_DONE gia' presenti in coda, senza mai bloccarsi
void drainDone(void) {
    struct message m;
    while (msgrcv(msqid, &m, MSG_SIZE, MSG_DONE, IPC_NOWAIT) != -1) {
        if (release(m.pid) != NULL)
            printf("[server] worker %d completed [%d/%d]\n", m.pid, running, maxProcs);
    }
}

// Un worker diventa "zombie" solo DOPO il suo msgsnd(MSG_DONE): si raccolgono
// prima tutti i pid terminati con waitpid, poi si svuotano i MSG_DONE arrivati
// nel frattempo, e solo allora un pid ancora "used" e' davvero morto senza
// notifica (crash, kill, timeout). L'ordine inverso lascerebbe una finestra in
// cui un worker appena terminato verrebbe scambiato per un errore.
void reap(void) {
    pid_t reaped[MAX_PROCS];
    int nReaped = 0;
    pid_t pid;
    while (nReaped < MAX_PROCS && (pid = waitpid(-1, NULL, WNOHANG)) > 0)
        reaped[nReaped++] = pid;
    if (nReaped == 0)
        return;

    drainDone();

    for (int i = 0; i < nReaped; i++) {
        struct active *a = release(reaped[i]);
        if (a != NULL) {
            printf("[server] worker %d terminated abnormally\n", reaped[i]);
            sendReply(a->req.pid, 1, 0, "worker terminated abnormally");
            semctl(a->req.semid, 0, IPC_RMID, 0);
            shmctl(a->req.shmid, IPC_RMID, NULL); // il client potrebbe essere morto
        }
    }
}

// Toglie dalla coda le richieste dei client morti (es. kill -9 mentre erano in attesa)
// e rimuove le risorse IPC che non hanno potuto ripulire. kill con segnale nullo
// non invia nulla: controlla solo se il processo esiste (ESRCH = non esiste)
void dropDeadClients(void) {
    int i = 0;
    while (i < pendCount) {
        if (kill(pend[i].req.pid, 0) == -1 && errno == ESRCH) {
            printf("[server] client %d is gone: request %s dropped\n", pend[i].req.pid,
                   pend[i].req.text);
            semctl(pend[i].req.semid, 0, IPC_RMID, 0);
            shmctl(pend[i].req.shmid, IPC_RMID, NULL);
            for (int j = i; j < pendCount - 1; j++)
                pend[j] = pend[j + 1];
            pendCount--;
        } else {
            i++;
        }
    }
}

// ------------------------------- admin -------------------------------

void handleAdmin(struct message *m) {
    char text[TEXT_LEN];

    if (m->cmd == CMD_SET_LIMIT) {
        if (m->value < 1 || m->value > MAX_PROCS) {
            snprintf(text, TEXT_LEN, "invalid limit (1..%d)", MAX_PROCS);
            sendReply(m->pid, 1, 0, text);
            return;
        }
        maxProcs = (int)m->value;
        printf("[server] process limit set to %d\n", maxProcs);
        snprintf(text, TEXT_LEN, "process limit: %d", maxProcs);
        sendReply(m->pid, 0, 0, text);
    } else if (m->cmd == CMD_STATUS) {
        // Risposta composta da piu' messaggi, uno per riga
        snprintf(text, TEXT_LEN, "policy: %s | limit: %d | running: %d | pending: %d",
                 policy == SJF ? "sjf" : "fcfs", maxProcs, running, pendCount);
        sendReply(m->pid, 0, 1, text);

        sendReply(m->pid, 0, 1, "RUNNING:");
        int lines = 0;
        for (int i = 0; i < MAX_PROCS && lines < MAX_STATUS_LINES; i++) {
            if (act[i].used) {
                snprintf(text, TEXT_LEN, "  worker %d <- client %d  %.30s (%ld B)", act[i].pid,
                         act[i].req.pid, act[i].req.text, act[i].req.size);
                sendReply(m->pid, 0, 1, text);
                lines++;
            }
        }
        if (running > MAX_STATUS_LINES) {
            snprintf(text, TEXT_LEN, "  ... and %d more", running - MAX_STATUS_LINES);
            sendReply(m->pid, 0, 1, text);
        }

        sendReply(m->pid, 0, 1, "PENDING (arrival order):");
        for (int i = 0; i < pendCount && i < MAX_STATUS_LINES; i++) {
            snprintf(text, TEXT_LEN, "  client %d  %.30s (%ld B)", pend[i].req.pid,
                     pend[i].req.text, pend[i].req.size);
            sendReply(m->pid, 0, 1, text);
        }
        if (pendCount > MAX_STATUS_LINES) {
            snprintf(text, TEXT_LEN, "  ... and %d more", pendCount - MAX_STATUS_LINES);
            sendReply(m->pid, 0, 1, text);
        }
        sendReply(m->pid, 0, 0, ""); // ultimo messaggio
    } else {
        sendReply(m->pid, 1, 0, "unknown command");
    }
}

// -------------------------------- main --------------------------------

void usage(const char *prog) {
    printf("Usage: %s [-p max_processes] [-s fcfs|sjf] [-d ms_per_block]\n", prog);
    printf("  -p  maximum number of worker processes (default %d, changeable with admin)\n",
           DEFAULT_PROCS);
    printf("  -s  scheduling of pending requests (default sjf)\n");
    printf("  -d  artificial delay in ms per %d-byte block, useful for tests\n", SHM_CHUNK);
    exit(1);
}

int main(int argc, char *argv[]) {
    int opt;
    while ((opt = getopt(argc, argv, "p:s:d:")) != -1) {
        switch (opt) {
        case 'p':
            maxProcs = atoi(optarg);
            if (maxProcs < 1 || maxProcs > MAX_PROCS)
                usage(argv[0]);
            break;
        case 's':
            if (strcmp(optarg, "fcfs") == 0)
                policy = FCFS;
            else if (strcmp(optarg, "sjf") == 0)
                policy = SJF;
            else
                usage(argv[0]);
            break;
        case 'd':
            delayUs = (useconds_t)atoi(optarg) * 1000;
            break;
        default:
            usage(argv[0]);
        }
    }

    setvbuf(stdout, NULL, _IOLBF, 0);

    // Coda di messaggi: fallisce se esiste gia' (altro server o residuo di un crash)
    key_t key = ftok(KEY_PATH, KEY_PROJ);
    if (key == -1)
        errExit("ftok failed");
    msqid = msgget(key, IPC_CREAT | IPC_EXCL | S_IRUSR | S_IWUSR);
    if (msqid == -1) {
        printf("Message queue already exists: another server is running, or it is\n");
        printf("left over from a crash (remove it with: ipcrm -Q 0x%x)\n", (unsigned)key);
        errExit("msgget failed");
    }

    // Semaforo di presenza: se esiste gia' e' un residuo di un precedente kill -9
    // (la msgget sopra e' appena riuscita, quindi nessun altro server e' in
    // esecuzione: e' sicuro riusarlo, azzerandolo prima di riportarlo a 1)
    int aliveSemid = semget(key, 1, IPC_CREAT | IPC_EXCL | S_IRUSR | S_IWUSR);
    if (aliveSemid == -1 && errno == EEXIST)
        aliveSemid = semget(key, 1, S_IRUSR | S_IWUSR);
    if (aliveSemid == -1)
        errExit("semget failed");
    if (semctl(aliveSemid, SEM_ALIVE, SETVAL, 0) == -1)
        errExit("semctl SETVAL failed");
    // SEM_UNDO: se il server termina in qualunque modo, il kernel riporta questa
    // operazione indietro da solo, azzerando il semaforo senza il suo intervento
    struct sembuf aliveOp = {.sem_num = SEM_ALIVE, .sem_op = 1, .sem_flg = SEM_UNDO};
    if (semop(aliveSemid, &aliveOp, 1) == -1)
        errExit("semop failed");

    if (signal(SIGINT, sigHandler) == SIG_ERR || signal(SIGTERM, sigHandler) == SIG_ERR ||
        signal(SIGALRM, sigHandler) == SIG_ERR)
        errExit("change signal handler failed");
    alarm(1);

    printf("[server] listening (queue %d), policy %s, max processes %d\n", msqid,
           policy == SJF ? "sjf" : "fcfs", maxProcs);

    while (!stop) {
        reap();
        dropDeadClients();
        dispatch();

        struct message m;
        if (msgrcv(msqid, &m, MSG_SIZE, -MSG_SERVER_MAX, 0) == -1) {
            if (errno == EINTR)
                continue; // segnale: si ricontrollano stop e worker
            errExit("msgrcv failed");
        }
        m.text[TEXT_LEN - 1] = '\0';

        switch (m.mtype) {
        case MSG_REQUEST:
            if (m.size < 0)
                sendReply(m.pid, 1, 0, "invalid request");
            else
                enqueue(&m);
            break;
        case MSG_ADMIN:
            handleAdmin(&m);
            break;
        case MSG_DONE:
            if (release(m.pid) != NULL)
                printf("[server] worker %d completed [%d/%d]\n", m.pid, running, maxProcs);
            break;
        }
    }

    // Arresto: i client in attesa vengono sbloccati rimuovendo i loro semafori
    printf("[server] shutting down\n");
    for (int i = 0; i < MAX_PROCS; i++) {
        if (act[i].used) {
            kill(act[i].pid, SIGTERM);
            sendReply(act[i].req.pid, 1, 0, "server shutting down");
            semctl(act[i].req.semid, 0, IPC_RMID, 0);
        }
    }
    for (int i = 0; i < pendCount; i++) {
        sendReply(pend[i].req.pid, 1, 0, "server shutting down");
        semctl(pend[i].req.semid, 0, IPC_RMID, 0);
    }
    while (wait(NULL) > 0)
        ;

    // Margine di grazia: da' ai client appena sbloccati il tempo di leggere la
    // propria risposta prima che la coda venga rimossa, altrimenti chi non e'
    // ancora stato schedulato vedrebbe solo il messaggio generico.
    struct msqid_ds ds;
    for (int waited = 0; waited < 20; waited++) { // fino a ~500 ms, a passi di 25 ms
        if (msgctl(msqid, IPC_STAT, &ds) == -1 || ds.msg_qnum == 0)
            break;
        usleep(25000);
    }

    if (msgctl(msqid, IPC_RMID, NULL) == -1)
        errExit("msgctl IPC_RMID failed");
    if (semctl(aliveSemid, 0, IPC_RMID, 0) == -1)
        errExit("semctl IPC_RMID failed");

    return 0;
}
