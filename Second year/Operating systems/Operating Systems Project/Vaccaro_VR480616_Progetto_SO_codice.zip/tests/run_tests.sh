#!/bin/bash
# Test di base: correttezza degli hash, concorrenza, ordine SJF/FCFS, aging, admin.
# Uso: tests/run_tests.sh [directory_build]
BUILD=${1:-build}
T=$(mktemp -d)
SRV=
cleanup() { [ -n "$SRV" ] && { kill $SRV 2>/dev/null; wait $SRV 2>/dev/null; }; rm -rf "$T"; }
trap cleanup EXIT
fail=0
check() { if [ "$2" = "$3" ]; then echo "OK   $1"; else echo "FAIL $1 (atteso '$3', ottenuto '$2')"; fail=1; fi; }
startServer() { $BUILD/server "$@" > $T/server.log 2>&1 & SRV=$!; sleep 0.5; }
stopServer() { kill $SRV; wait $SRV 2>/dev/null; SRV=; }

head -c 0 /dev/zero > $T/vuoto
head -c 10 /dev/urandom > $T/piccolo
head -c 4096 /dev/urandom > $T/blocco
head -c 100000 /dev/urandom > $T/medio
head -c 1000000 /dev/urandom > $T/grande

startServer -p 2 -s sjf -d 20

# 1. correttezza su varie dimensioni (incluso file vuoto e multiplo del blocco)
for f in vuoto piccolo blocco medio; do
    check "hash $f" "$($BUILD/client $T/$f | cut -d' ' -f1)" "$(sha256sum $T/$f | cut -d' ' -f1)"
done

# 2. richieste concorrenti, risultati non mescolati
pids=
for i in 1 2 3 4 5 6; do ( $BUILD/client $T/medio | cut -d' ' -f1 > $T/out$i ) & pids="$pids $!"; done
wait $pids
exp=$(sha256sum $T/medio | cut -d' ' -f1)
for i in 1 2 3 4 5 6; do check "concorrente $i" "$(cat $T/out$i)" "$exp"; done

# 3. limite dinamico e stato
$BUILD/admin limit 1 | grep -q "process limit: 1"; check "admin limit" $? 0
$BUILD/admin limit 0 >/dev/null; check "admin limit non valido" $? 1
$BUILD/client $T/grande >/dev/null & P1=$!
sleep 0.3
$BUILD/client $T/medio >/dev/null & P2=$!
$BUILD/client $T/piccolo >/dev/null & P3=$!
sleep 0.3
st=$($BUILD/admin status)
echo "$st"
echo "$st" | grep -q "running: 1"; check "status in esecuzione" $? 0
echo "$st" | grep -q "pending: 2"; check "status in attesa" $? 0
wait $P1 $P2 $P3

# 4. SJF: con limite 1, tra i pendenti parte prima il piu' piccolo
check "ordine SJF" "$(grep 'started worker' $T/server.log | tail -3 | grep -o 'piccolo\|medio\|grande' | tr '\n' ' ')" "grande piccolo medio "
stopServer

# 5. FCFS: ordine di arrivo
startServer -p 1 -s fcfs -d 20
$BUILD/client $T/grande >/dev/null & P1=$!
sleep 0.3
$BUILD/client $T/medio >/dev/null & P2=$!
sleep 0.1
$BUILD/client $T/piccolo >/dev/null & P3=$!
wait $P1 $P2 $P3
check "ordine FCFS" "$(grep 'started worker' $T/server.log | grep -o 'piccolo\|medio\|grande' | tr '\n' ' ')" "grande medio piccolo "
stopServer

# 5b. aging: una richiesta ferma in coda a lungo finisce comunque per essere
#     scelta, anche se nel frattempo continuano ad arrivare file piu' piccoli
head -c 1200000 /dev/urandom > $T/blocker
head -c 25000   /dev/urandom > $T/aging
startServer -p 1 -s sjf -d 15
$BUILD/client $T/blocker >/dev/null &
sleep 0.3
$BUILD/client $T/aging >/dev/null &
for i in $(seq 21); do $BUILD/client $T/piccolo >/dev/null 2>&1 & sleep 0.2; done
wait $(jobs -p | grep -v $SRV)
next=$(grep 'started worker' $T/server.log | sed -n '2p' | grep -o 'aging\|piccolo')
check "aging: la richiesta piu' vecchia supera i file piccoli appena arrivati" "$next" "aging"
stopServer

# 5c. non regressione: un worker che termina correttamente non deve mai essere
#     scambiato per uno terminato in modo anomalo (si veda la relazione, sezione 6)
startServer -p 4 -d 10
for i in $(seq 60); do $BUILD/client $T/piccolo >/dev/null 2>&1 & done
wait $(jobs -p | grep -v $SRV)
check "nessun falso 'terminated abnormally' (reap/MSG_DONE)" \
      "$(grep -c 'terminated abnormally' $T/server.log)" "0"
stopServer

# 5d. non regressione: un client non deve restare bloccato per sempre se si
#     connette a una coda lasciata da un server ucciso con kill -9
$BUILD/server -p 1 >/dev/null 2>&1 & SRV=$!; sleep 0.5
kill -9 $SRV; wait $SRV 2>/dev/null
t0=$(date +%s)
timeout 8 $BUILD/client $T/piccolo >/dev/null 2>&1; rc=$?
t1=$(date +%s)
check "client su coda orfana: esce con errore invece di bloccarsi" "$rc" "1"
check "client su coda orfana: se ne accorge in pochi secondi" \
      "$([ $((t1-t0)) -le 5 ] && echo si)" "si"
for id in $(ipcs -q | awk '/^0x/{print $2}'); do ipcrm -q $id 2>/dev/null; done
for id in $(ipcs -s | awk '/^0x/{print $2}'); do ipcrm -s $id 2>/dev/null; done
SRV=

# 6. file inesistente e server assente
$BUILD/client $T/nonesiste >/dev/null 2>&1; check "file inesistente" $? 1
$BUILD/client $T/medio >/dev/null 2>&1; check "server assente" $? 1

# 7. nessuna risorsa IPC residua
check "nessuna risorsa IPC residua" "$(ipcs | grep -c '^0x')" "0"

[ $fail = 0 ] && echo "TUTTI I TEST OK" || echo "ALCUNI TEST FALLITI"
exit $fail
